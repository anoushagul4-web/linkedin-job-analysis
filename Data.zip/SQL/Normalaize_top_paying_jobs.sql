SELECT title,
       company_name,
       normalized_salary
FROM postings
WHERE normalized_salary BETWEEN 30000 AND 300000
ORDER BY normalized_salary DESC
LIMIT 10;
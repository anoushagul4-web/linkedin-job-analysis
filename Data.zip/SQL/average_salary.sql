SELECT ROUND(AVG(normalized_salary),2) AS avg_salary
FROM postings
WHERE normalized_salary IS NOT NULL;
SELECT remote_allowed,
       COUNT(*) AS jobs
FROM postings
GROUP BY remote_allowed;
SELECT company_name,
       COUNT(*) AS total_jobs
FROM postings
WHERE company_name IS NOT NULL
GROUP BY company_name
ORDER BY total_jobs DESC
LIMIT 10;
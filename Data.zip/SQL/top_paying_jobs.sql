SELECT title,
       company_name,
       normalized_salary
FROM postings
WHERE normalized_salary IS NOT NULL
ORDER BY normalized_salary DESC
LIMIT 10;
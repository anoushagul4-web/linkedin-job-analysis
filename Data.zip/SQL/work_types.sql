SELECT work_type,
       COUNT(*) AS jobs
FROM postings
WHERE work_type IS NOT NULL
GROUP BY work_type
ORDER BY jobs DESC;